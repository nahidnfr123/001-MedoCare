<?php

use App\DoctorRating;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class DoctorRatingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

    }
}
